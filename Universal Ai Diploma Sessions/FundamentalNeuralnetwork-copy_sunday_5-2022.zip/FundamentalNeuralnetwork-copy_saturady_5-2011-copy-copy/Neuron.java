import java.util.ArrayList;
import java.util.Random;

public class Neuron
{
//features
private double eta; // learning rate
private double alpha;//momentum
private double gradient;
private double outcome;
private int neuronId;
private int numberWeightsFromNextNeuron;
private ArrayList <Synapse> weights = new ArrayList <Synapse> ();

//constructor
public  Neuron (double eta, double alpha, int neuronId, int numberWeightsFromNextNeuron)
{
this.eta = eta;
this.alpha = alpha;
this.neuronId = neuronId;
this.numberWeightsFromNextNeuron = numberWeightsFromNextNeuron;
gradient = 0.0;

// initialize my weights
for (int wI = 0; wI < numberWeightsFromNextNeuron; wI ++)
{
    weights.add (new Synapse());
    weights.get (wI).setWeight (new Random ().nextDouble () );
}


}
//method
//getters
public double getOutcome ()
{
    return outcome;
}
public double getGradient ()
{
    return gradient;
}
public ArrayList <Synapse> getWeights ()
{
    return weights;
}
public double getActivation (double value)
{
    return Math.tanh (value);
}
public double getPrimeActivation (double value)
{
    return 1 - Math.pow (Math.tanh (value) , 2);
}
public double getDistributedWeightSigma (Layer nextLayer)
{
    double sigma = 0.0;
    for (int nLI = 0; nLI < nextLayer.size ()- 1; nLI++)
    {
    //multiply our weights times the gradients for next layer
    sigma+= getWeights ().get (nLI).getWeight () * nextLayer.get (nLI).getGradient();
    }
    
    return sigma;
}

//setters
public void setGradient (double value)
{
    gradient = value;
}
public void setOutcome (double value)
{
    outcome = value;
}
public void setHiddenGradient (Layer nextLayer)
{
    double delta = getDistributedWeightSigma (nextLayer);
    
    setGradient (getPrimeActivation (outcome) * delta);
}

public void setOutcomeGradient (int target)
{
    double delta = target - outcome;
    
    setGradient (getPrimeActivation (outcome) * delta);
}
public void doForwardPropagation (Layer priorLayer) 
{
double sigma = 0.0;
//multiply weights times outcomes of priorLayer

for (int pLI = 0; pLI < priorLayer.size (); pLI ++)
{
    sigma += priorLayer.get (pLI).getWeights().get (neuronId).getWeight() *priorLayer.get(pLI).getOutcome();
}
setOutcome (getActivation(sigma));
}

public void updateWeights (Layer priorLayer)
{
for (int pLI = 0; pLI < priorLayer.size (); pLI ++)

{
   double priorDeltaWeight = priorLayer.get (pLI).getWeights().get (neuronId).getDeltaWeight();
   
   // new delta weight = (eta * thisNeuron_Gradient * priorLayer_outcome) + (alpha *priorDeltaWeight)
   double newDeltaWeight = (eta * gradient * priorLayer.get (pLI). getOutcome())+ (alpha * priorDeltaWeight);
   //
   priorLayer.get (pLI).getWeights().get (neuronId). setDeltaWeight (newDeltaWeight);
   // update weights with respect to new delta weiht above
      double priorWeight = priorLayer.get (pLI).getWeights ().get (neuronId).getWeight();
      priorLayer.get (pLI).getWeights().get (neuronId).setWeight(priorWeight + newDeltaWeight);
}

}

}

