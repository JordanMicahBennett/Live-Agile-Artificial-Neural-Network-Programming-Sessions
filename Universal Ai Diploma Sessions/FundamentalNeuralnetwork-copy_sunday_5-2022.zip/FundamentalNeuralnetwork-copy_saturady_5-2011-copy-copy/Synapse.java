public class Synapse
{
// features
private double weight;
private double deltaWeight;

//methods for getting features
public double getWeight ()
{
    return weight;
}
public double getDeltaWeight ()
{
    return deltaWeight;
}
    

// methods for setting features
public void setWeight (double value)
{
     weight = value;
}
public void setDeltaWeight (double value)
{
 deltaWeight = value;
}




}



