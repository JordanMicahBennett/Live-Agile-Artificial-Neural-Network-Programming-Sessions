public class NeuralNetwork
{

    //features
    private double eta = 0.2; //learning rate
    private double alpha = 0.5; // momentum (affects gradient changes/descent)
    private Layers layers = new Layers ();
    private Structure structure = new Structure ("2,2,1");// guides numerically how we build our neuron collection and manipulate said connectio
    
    //constructor
    public NeuralNetwork()
    {
        //nested loops to build neuron collection guides the Structure class instance "structure"
        for (int lSI = 0; lSI < structure.size ();lSI ++)
        {
            
            layers.add (new Layer()); // add new layer, because saying Layers layers = new Layers do not add any actual instances of layer object
            for (int lI = 0; lI <= structure.get (lSI);lI ++) 
            
            {
            
                int numberWeightsFromNextNeuron = (lSI + 1 < structure.size()? structure.get(lSI +1) : 0);
                
                Neuron newNeuron = new Neuron (eta,alpha,lI, numberWeightsFromNextNeuron);
                
                layers.get (lSI ). add ( newNeuron);
                
                Neuron lastNeuronPerLayer = layers.get (lSI).get (layers.get(lSI).size() -1);
                
                lastNeuronPerLayer.setOutcome (1.0);
            }
        }
    }
   
     
    // methods
    
    // do forward propagation
    public void doForwardPropagation (int[ ]inputs)
    {
        for (int iI = 0;iI < inputs.length; iI ++)
                layers.get (0).get (iI).setOutcome (inputs [ iI ] );
                
        for (int lSI = 1; lSI < structure.size ( ); lSI ++)
          {
            Layer priorLayer = layers.get (lSI - 1);
            
            for (int lI = 0; lI < structure.get (lSI);lI ++)
            {
            layers.get (lSI).get (lI).doForwardPropagation (priorLayer);
            }         
        }
    }
    // do backward propagation 
    public void doBackwardPropagation (int target)
    {
    
    //set outcome gradient 
    Neuron outcomeNeuron = layers.get (layers.size() -1).get (0);
    outcomeNeuron.setOutcomeGradient (target);
    
    //set hidden gradient
    for (int lSI = structure.size  () -2 ; lSI > 0;lSI--)
    {
        Layer currentLayer = layers.get (lSI);
        Layer nextLayer = layers.get (lSI + 1);
        
        for (int lI = 0; lI <currentLayer.size( ) ; lI ++)
        {
        layers.get (lSI).get (lI).setHiddenGradient (nextLayer);
        }
    }
    //update weights
    for (int lSI = structure.size  () -1 ; lSI > 0;lSI--)
    {
        Layer currentLayer = layers.get (lSI);
        Layer priorLayer = layers.get (lSI - 1);
        
        for (int lI = 0; lI <currentLayer.size( ) - 1; lI ++)
        {
        layers.get (lSI).get (lI).updateWeights (priorLayer);
        }
    }
    }
    
    
    //get neural network answer
    public double getOutcome ()
    {
        Neuron firstNeuronInLastLayer = layers.get (layers.size( )  -1).get (0);
        return firstNeuronInLastLayer.getOutcome();
        
    }

}
