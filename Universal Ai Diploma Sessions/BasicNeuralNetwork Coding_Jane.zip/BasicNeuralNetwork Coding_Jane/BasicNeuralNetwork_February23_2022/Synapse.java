public class Synapse
{
    //features /attributes
    private double weight;
    private double deltaWeight;
    
    //methods
    //get methods
    public double getWeight ( )
    {
        return weight;
    }
    public double getDeltaWeight ( )
    {
        return deltaWeight;
    }
    
    //set methods
    public void setWeight ( double value )
    {
        weight = value;
    }
    
    public void setDeltaWeight ( double value )
    {
        deltaWeight = value;
    }
}