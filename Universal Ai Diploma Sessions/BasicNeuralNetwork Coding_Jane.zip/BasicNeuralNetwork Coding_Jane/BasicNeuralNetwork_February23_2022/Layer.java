import java.util.ArrayList;

public class Layer extends ArrayList <Neuron>
{
}