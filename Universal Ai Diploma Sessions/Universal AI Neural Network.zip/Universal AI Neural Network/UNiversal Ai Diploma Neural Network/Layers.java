import java.util.ArrayList;


public class Layers extends ArrayList <Layer>
{
}
