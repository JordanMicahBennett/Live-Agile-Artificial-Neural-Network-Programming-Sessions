import java.util.ArrayList;

public class StructureDescription extends ArrayList <Integer>
{
    //feature
    private String description;
    
    
    //constructor
    //Eg: description 2,2,1
    public StructureDescription ( String description )
    {
        String [ ] descriptionParts = description.split ( "," );
        
        for ( int dP = 0; dP < descriptionParts.length; dP ++ ) 
        {
            add ( Integer.parseInt ( descriptionParts [ dP ] ) );
        }
    }
}