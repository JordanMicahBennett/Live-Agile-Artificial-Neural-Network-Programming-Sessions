public class NeuralNetwork
{
    //features
    private double eta = 0.2;
    private double alpha = 0.5;
    private StructureDescription architecture = new StructureDescription ( "2,2,1" );
    private Layers layers;
    
    //constructor 
    public NeuralNetwork ( )
    {
        layers = new Layers ( );
        
        for ( int lSI = 0; lSI < architecture.size ( ); lSI ++ )
        {
            layers.add ( new Layer ( ) );
            
            for ( int lI = 0; lI <= architecture.get ( lSI ); lI ++ )
            {
                int numberOfWeightsFromNextNeuron = ( lSI + 1 < architecture.size ( ) ) ? architecture.get ( lSI + 1 ) : 0;
                
                Neuron neuron = new Neuron ( eta, alpha, lI, numberOfWeightsFromNextNeuron );
                
                layers.get ( lSI ).add ( neuron );
                
                layers.get ( lSI ).get ( layers.get ( lSI ).size ( ) - 1 ).setOutcome ( 1.0 );
            }
        }
    }
    
    //methods
    //forward propagation
    public void doForwardPropagation ( int [ ] inputs )
    {
        for ( int iI = 0; iI < inputs.length; iI ++ )
            layers.get ( 0 ).get ( iI ).setOutcome ( inputs [ iI ] );
            
            
        for ( int lSI = 1; lSI < architecture.size ( ); lSI ++ )   
            for ( int lI = 0; lI < architecture.get ( lSI ); lI ++ )
            {
                Layer priorLayer = layers.get ( lSI - 1 );
                
                layers.get ( lSI ).get ( lI ).doForwardPropagation ( priorLayer );
            }
    }
    
    //backward propagation
    public void doBackwardPropagation ( int target )
    {
        //outcome gradient calculate
        Neuron firstNeuronOfLastLayer = layers.get ( layers.size ( ) - 1 ).get ( 0 );
        firstNeuronOfLastLayer.calculateOutcomeGradient ( target );
        
        //hidden gradient calculation
        for ( int lSI = layers.size()-2; lSI > 0; lSI -- )
        {
            Layer currentLayer = layers.get ( lSI );
            Layer nextLayer = layers.get ( lSI + 1 );
            
            for ( int lI = 0; lI < currentLayer.size ( ); lI ++ )
                currentLayer.get ( lI ).calculateHiddenGradient ( nextLayer );
        }
        
        //weights update calculation
        for ( int lSI = layers.size()-1; lSI > 0; lSI -- )
        {
            Layer currentLayer = layers.get ( lSI );
            Layer priorLayer = layers.get ( lSI - 1 );
            
            for ( int lI = 0; lI < currentLayer.size ( ) - 1; lI ++ )
                currentLayer.get ( lI ).updateWeights ( priorLayer );
        }
    }
    
    //outcome
    public double getOutcome ( )
    {
        Neuron firstNeuronOfLastLayer = layers.get ( layers.size ( ) - 1 ).get ( 0 );
        return firstNeuronOfLastLayer.getOutcome ( );
    }
}