import java.util.ArrayList;
import java.util.Random;

public class Neuron
{
    //features
    private double eta; //learning rate
    private double alpha; //momentum 
    private int neuronId; //id
    private ArrayList <Synapse> weights;
    private double gradient;
    private double outcome;
    private int numberOfWeightsFromNextNeuron;
    
    //constructor
    public Neuron ( double eta, double alpha, int neuronId, int numberOfWeightsFromNextNeuron )
    {
        this.eta = eta;
        this.alpha = alpha;
        this.neuronId = neuronId;
        this.numberOfWeightsFromNextNeuron = numberOfWeightsFromNextNeuron;
        gradient = 0;
        
        //define weights
        weights = new ArrayList <Synapse> ( );
        
        for ( int wI = 0; wI < numberOfWeightsFromNextNeuron; wI ++ )
        {
            weights.add ( new Synapse ( ) );
            
            weights.get ( wI ).setWeight ( new Random ( ).nextDouble ( ) ); //sets weight to a value between 0 and 1
        }
    }
    
    //methods
    //accesors or getters
    public double getOutcome ( )
    {
        return outcome;
    }
    public double getGradient ( )
    {
        return gradient;
    }
    public double getActivation ( double value )
    {
        return Math.tanh ( value );
    }
    public double getPrimeActivation ( double value )
    {
        return 1 - Math.pow ( Math.tanh ( value ), 2 );
    }
    public ArrayList <Synapse>  getWeights ( )
    {
        return weights;
    }
    public double getDistributedWeightSigma ( Layer nextLayer )
    {
        double sigma = 0;
        
        //product of weights and gradients of the next layer 
        for ( int nLI = 0; nLI < nextLayer.size ( ) - 1; nLI ++ )
        {
            sigma += getWeights ( ).get ( nLI ).getWeight ( ) * nextLayer.get ( nLI ).getGradient ( );
        }
        
        return sigma;
    }

    //setters
    public void setGradient ( double value )
    {
        gradient = value;
    }
    public void setOutcome ( double value )
    {
        outcome = value;
    }
    public void calculateHiddenGradient ( Layer nextLayer )
    {
        double delta = getDistributedWeightSigma ( nextLayer );
        
        setGradient ( getPrimeActivation ( outcome ) * delta );
    }
    public void calculateOutcomeGradient ( int target )
    {
        double delta = target - outcome;
        
        setGradient ( getPrimeActivation ( outcome ) * delta );
    }
    public void doForwardPropagation ( Layer priorLayer )
    {
        //product of the weights and outcomes of the prior layer
        double sigma = 0;
        
        for ( int pLI = 0; pLI < priorLayer.size ( ); pLI ++ )
            sigma += priorLayer.get ( pLI ).getWeights ( ).get ( neuronId ).getWeight ( ) * priorLayer.get ( pLI ).getOutcome ( );
            
            
        setOutcome ( getActivation ( sigma ) );
    }
    public void updateWeights ( Layer priorLayer )
    {
        for ( int pLI = 0; pLI < priorLayer.size ( ); pLI ++ )
        {
            double priorDeltaWeight = priorLayer.get ( pLI ).getWeights ( ).get ( neuronId ).getDeltaWeight ( );
            
            //sum of products of eta, gradient, outcome and alpha, prior delta weight
            //eta * thisGradient * prior Layer's outcome + alpha * priorDeltaWeight
            double newDeltaWeight = eta * getGradient ( ) * priorLayer.get ( pLI ).getOutcome ( ) + alpha * priorDeltaWeight;
            
            priorLayer.get ( pLI ).getWeights ( ).get ( neuronId ).setDeltaWeight ( newDeltaWeight );
            priorLayer.get ( pLI ).getWeights ( ).get ( neuronId ).setWeight ( priorLayer.get ( pLI ).getWeights ( ).get ( neuronId ).getWeight ( ) + newDeltaWeight );
        }
    }
}
