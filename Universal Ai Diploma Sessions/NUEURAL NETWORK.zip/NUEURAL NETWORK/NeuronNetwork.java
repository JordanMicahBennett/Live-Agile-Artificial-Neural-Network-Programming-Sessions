public class NeuronNetwork
{
    //features
    private double eta = 0.2;
    private double alpha = 0.5;
    private Structure NeuronNetworkDescription = new Structure ("2,2,1" );
    private Layers layers = new Layers();
    
    //constructor
    public NeuronNetwork()
    {
        //consider total no. of layers
        //consider total no. of neurons
        for (int lSI = 0; lSI <NeuronNetworkDescription.size();lSI ++)
        
        {
            layers.add (new Layer());
           for (int  lI = 0; lI <= NeuronNetworkDescription.get (lSI) ; lI ++)
           {
           
           int numberOfWeightsFromNeuron = (lSI + 1< NeuronNetworkDescription.size() ? NeuronNetworkDescription.get(lSI + 1):0); 
           
           Neuron newNeuron = new Neuron (eta, alpha , lI, numberOfWeightsFromNeuron);
           layers.get (lSI).add(newNeuron);
           Neuron lastNeuronPerLayer=layers.get (lSI). get(layers.get(lSI).size()-1);
           lastNeuronPerLayer.setOutcome(1.0);
           }
        }

    }
    
    
    
    //methods
    public void doForwardPropagation (int [] inputs)
    {
        for( int iI = 0; iI < inputs.length; iI ++)
        layers.get(0).get (iI).setOutcome(inputs[iI]);
        
        for (int lSI = 1; lSI <NeuronNetworkDescription.size();lSI ++)
        {
           Layer priorLayer = layers.get(lSI - 1);
            for (int iI = 0; iI <NeuronNetworkDescription.get(lSI);iI ++) 
          {
             
             layers.get(lSI).get(iI).doForwardPropagation(priorLayer);
          }
        }
    }
    public void doBackwardPropagation (int target)
    {
        //calculate outcome gradient
        Neuron outcomeNeuron = layers.get(layers.size()-1).get(0);
        outcomeNeuron.setOutcomeGradient(target);
        
        //neuron gradient
        for (int lSI=NeuronNetworkDescription.size()-2; lSI>0;lSI--)
        {
            Layer currentLayer = layers.get(lSI);
            Layer nextLayer = layers.get(lSI +1);
            for( int iI = 0; iI < currentLayer.size(); iI ++)
            currentLayer.get(iI).setHiddenGradient(nextLayer);
        }
        
        
        
        
        //update weight
        for (int lSI=NeuronNetworkDescription.size()-1; lSI>0;lSI--)
        {
            Layer currentLayer = layers.get(lSI);
            Layer priorLayer = layers.get(lSI -1);
            for( int iI = 0; iI < currentLayer.size()-1; iI ++)
            currentLayer.get(iI).updateWeights(priorLayer);
        }
    }
    
    public double getOutcome()
    {
        Neuron outcomeNeuron = layers.get(layers.size()-1).get(0);
        return outcomeNeuron.getOutcome();
    }
}