import java.util.ArrayList;

public class Structure extends ArrayList <Integer>
{
   //feature-neural network description
   //eg;2,2,1
   private String description;
   public Structure(String externalDescription)
   {
       this.description = externalDescription;
       
       String [] parts = description.split(",");
       //pI -parts iteration index
       for (int pI = 0; pI < parts.length; pI ++)
       add (Integer.parseInt(parts[ pI ] ));
    }
}