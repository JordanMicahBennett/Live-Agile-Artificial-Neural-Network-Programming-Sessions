import java.util.ArrayList;
import java.util.Random;
public class Neuron
{
   //features
   private double eta;//learning rate
   private double alpha; //momentum
   private double outcome;//neuron's value
   private double gradient; //small chNGES THE NEURAL NETWORK LEARNS DURIN FORWRAD AND BACK ROPAGATION
   private int numberOfWeightsFromNextNeuron;
   private int neuronId; //to identify each neuron object
   private ArrayList <Synapse> weights;
   
   
   //constructor
   public Neuron (double eta, double alpha, int neuronId,int numberOfWeightsFromNextNeuron)
   {
       gradient= 0.0;
       this.eta = eta;
       this.alpha = alpha;
       this.neuronId = neuronId;
       this.numberOfWeightsFromNextNeuron = numberOfWeightsFromNextNeuron;
       
       //describe starting weights
       weights = new ArrayList <Synapse>();
       
       for (int wI = 0; wI< this.numberOfWeightsFromNextNeuron; wI ++)
       {
           weights.add(new Synapse());
           weights.get(wI).setWeight(new Random ( ).nextDouble());
       }
       
   }
   //get methods
   public double getOutcome()
   {
       return outcome;
   }
   public double getGradient()
   {
       return gradient;
   }
   public ArrayList <Synapse> getWeights()
   {
       return weights;
   }
   public double getActivation (double value)
   {
       //tangetial function on the input value
       return  Math.tanh(value);
       
   }
   public double getPrimeActivation  (double value)
   {
       //tangetial function on the input value
       return 1 - Math.pow(Math.tanh(value),2);
}
public double getDistributedWeightSigma (Layer nextLayer)

{
 double sigma = 0;
 for (int nLI = 0;nLI <nextLayer.size() -1; nLI ++)
 {
    sigma += getWeights ().get (nLI).getWeight() * nextLayer.get(nLI).getGradient();
    

 }    return sigma;
}
//set methods

public void setOutcome (double value)
{
    outcome = value;
}
 public void setGradient (double value)
{

    gradient = value;
}
public void setOutcomeGradient (int target)
{
    double delta = target -  outcome;
    //set gradient to prime activation of deriavative of outcome multiplied by delta
    setGradient (getPrimeActivation (outcome) * delta );
}
public void setHiddenGradient (Layer nextLayer)
{
    double delta = getDistributedWeightSigma ( nextLayer);
    setGradient (getPrimeActivation (outcome) * delta );
    
}
public void doForwardPropagation (Layer priorLayer )
{
    double sigma = 0;
    //those weights * those outcomes
    for (int pLI = 0; pLI < priorLayer.size (); pLI ++)
    {
        sigma += priorLayer.get (pLI).getWeights().get(neuronId).getWeight()*priorLayer.get(pLI).getOutcome();
    }
    setOutcome (getActivation(sigma));
}
public void updateWeights (Layer priorLayer)
{
for (int pLI = 0; pLI < priorLayer.size (); pLI ++)
    {
        //update delta weihts
        //update weights respect weight
        double priorDeltaWeight = priorLayer.get(pLI).getWeights().get(neuronId).getDeltaWeight();
        
        double newDeltaWeight = (eta * getGradient() * priorLayer.get(pLI).getOutcome()) + (alpha *priorDeltaWeight);
        //update weights and delta weights
        priorLayer.get(pLI).getWeights().get(neuronId).setDeltaWeight(newDeltaWeight);
        double thatWeight =priorLayer.get(pLI).getWeights().get(neuronId).getWeight(); 
        priorLayer.get(pLI).getWeights().get(neuronId).setWeight(priorLayer.get(pLI).getWeights().get(neuronId).getWeight( ) + newDeltaWeight);
        
        
    }
    

}}
