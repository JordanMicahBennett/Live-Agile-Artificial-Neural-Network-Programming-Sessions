
public class __SHELL11 extends bluej.runtime.Shell {
public static void run() throws Throwable {

java.lang.String[] __bluej_param0 = { };
RunNeuronNetwork.main(__bluej_param0);

}}
